Backbone = require(["backbone"]);

KBB = Backbone.Model.extend({
	makes: ["Acura", "Alfa Romeo", "Aston Martin", "Audi", "Bentley", "BMW", "Buick", "Cadillac", 
	"Chevrolet", "Chrysler", "Daewoo", "Dodge", "Eagle", "Ferrari", "FIAT", "Fisker", "Ford", "Geo", 
	"GMC", "Honda", "HUMMER", "Hyundai", "Infinit(i", "y)", "Isuzu", "Jaguar", "Jeep", "Kia", "Lamborghini", 
	"Land Rover", "Lexus", "Lincoln", "Lotus", "Maserati", "Maybach", "Mazda", "McLaren", "Mercedes-Benz", 
	"Mercury", "MINI", "Mitsubishi", "Nissan", "Oldsmobile", "Panoz", "Plymouth", "Pontiac", "Porsche", "Ram", 
	"Rolls-Royce", "Saab", "Saturn", "Scion", "smart", "SRT", "Subaru", "Suzuki", "Tesla", "Toyota", "Volkswagen", 
	"Volvo"],
	years: [1994, 1995, 1996, 1997, 1998, 1999, 2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014],
	makeDropDown: function(){

	},
	yearDropDown: function(){

	}

})

Car = Backbone.Model.extend();